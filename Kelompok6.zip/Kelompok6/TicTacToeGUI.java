package tic_tac_toe;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class TicTacToeGUI extends JFrame {
    private JButton[][] cells;
    private JLabel statusLabel, timerLabel;
    private boolean player1Turn;
    private boolean gameEnded;
    private int numMoves;
    private Player player1, player2;
    private Timer timer;           
    private int timeRemaining;    

    public TicTacToeGUI(Player p1, Player p2) {
        player1 = p1;
        player2 = p2;
        setTitle("GAME: Tic Tac Toe");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        
        JPanel gridPanel = new JPanel(new GridLayout(3, 3));
        cells = new JButton[3][3];

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                cells[row][col] = new JButton("");
                cells[row][col].setFont(new Font("Arial", Font.BOLD, 50));
                cells[row][col].setBackground(new Color(47, 104, 121));
                cells[row][col].setForeground(new Color(124, 221, 210));
                final int r = row, c = col;
                cells[row][col].addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        buttonClicked(r, c);
                    }
                });
                gridPanel.add(cells[row][col]);
            }
        }
        add(gridPanel);

        
        statusLabel = new JLabel(player1.getName() + "'s turn (O)");
        statusLabel.setFont(new Font("Arial", Font.BOLD, 35));
        getContentPane().setBackground(new Color(172, 198, 197));
        statusLabel.setForeground(new Color(47, 104, 121));
        statusLabel.setPreferredSize(
                new Dimension(statusLabel.getPreferredSize().width + 150, statusLabel.getPreferredSize().height + 6));
        statusLabel.setHorizontalAlignment(JLabel.CENTER);
        add(statusLabel, BorderLayout.SOUTH);

        
        timerLabel = new JLabel("Time Remaining: 30s", JLabel.CENTER);
        timerLabel.setFont(new Font("Arial", Font.BOLD, 25));
        timerLabel.setForeground(new Color(47, 104, 121));
        JPanel topPanel = new JPanel(new GridLayout(2, 1));
        JLabel playersLabel = new JLabel(player1.getName() + " (X) vs " + player2.getName() + " (O)", JLabel.CENTER);
        playersLabel.setFont(new Font("Arial", Font.BOLD, 25));
        playersLabel.setForeground(new Color(47, 104, 121));
        topPanel.add(playersLabel);
        topPanel.add(timerLabel);
        add(topPanel, BorderLayout.NORTH);

        setSize(650, 650);
        setLocationRelativeTo(null);
        setVisible(true);

        
        timeRemaining = 30;
        timer = new Timer(1000, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateTimer();
            }
        });
        timer.start();
    }

    private void buttonClicked(int row, int col) {
        if (gameEnded) {
            JOptionPane.showMessageDialog(this, "Game has ended. Please start a new game.");
            return;
        }

        
        if (!cells[row][col].getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Cell is already taken. Please choose another cell.");
            return;
        }

        
        if (player1Turn) {
            cells[row][col].setText("X");
            statusLabel.setText(player1.getName() + "'s turn (O)");
        } else {
            cells[row][col].setText("O");
            statusLabel.setText(player2.getName() + "'s turn (X)");
        }
        numMoves++;

        
        timeRemaining = 30;
        timer.restart();  

        
        if (numMoves >= 5) {
            if (checkWinner(row, col)) {
                gameEnded = true;
                String winner = player1Turn ? player2.getName() : player1.getName();
                statusLabel.setText("CONGRATS " + winner + "!!");
                JOptionPane.showMessageDialog(this, "Congratulations " + winner + ", you won!");
                int choice = JOptionPane.showConfirmDialog(this, "Do you want to play again?", "Play Again?", JOptionPane.YES_NO_OPTION);
                if (choice == JOptionPane.YES_OPTION) {
                    resetGame();
                } else {
                    dispose();
                }
            } else if (numMoves == 9) {
                gameEnded = true;
                statusLabel.setText("DRAW!!");
                JOptionPane.showMessageDialog(this, "Game is a draw.");
                int choice = JOptionPane.showConfirmDialog(this, "Do you want to play again?", "Play Again?", JOptionPane.YES_NO_OPTION);
                if (choice == JOptionPane.YES_OPTION) {
                    resetGame();
                } else {
                    dispose();
                }
            }
        }

        player1Turn = !player1Turn;
    }

    private void resetGame() {
        player1Turn = true;
        gameEnded = false;
        numMoves = 0;

        
        timeRemaining = 30;
        timer.restart();  

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                cells[row][col].setText("");
                cells[row][col].setBackground(new Color(47, 104, 121));
            }
        }

        statusLabel.setText(player1.getName() + "'s turn");
        timerLabel.setText("Time Remaining: 30s");
    }

    private boolean checkWinner(int row, int col) {
        String mark = player1Turn ? "X" : "O";

        
        if (cells[row][0].getText().equals(mark) && cells[row][1].getText().equals(mark)
                && cells[row][2].getText().equals(mark)) {
            highlightWinningCells(row, 0, row, 1, row, 2);
            return true;
        }

       
        if (cells[0][col].getText().equals(mark) && cells[1][col].getText().equals(mark)
                && cells[2][col].getText().equals(mark)) {
            highlightWinningCells(0, col, 1, col, 2, col);
            return true;
        }

        
        if (row == col && cells[0][0].getText().equals(mark) && cells[1][1].getText().equals(mark)
                && cells[2][2].getText().equals(mark)) {
            highlightWinningCells(0, 0, 1, 1, 2, 2);
            return true;
        }

        
        if (row + col == 2 && cells[0][2].getText().equals(mark) && cells[1][1].getText().equals(mark)
                && cells[2][0].getText().equals(mark)) {
            highlightWinningCells(0, 2, 1, 1, 2, 0);
            return true;
        }

        return false;
    }

    private void highlightWinningCells(int r1, int c1, int r2, int c2, int r3, int c3) {
        cells[r1][c1].setBackground(new Color(98, 140, 88));
        cells[r2][c2].setBackground(new Color(98, 140, 88));
        cells[r3][c3].setBackground(new Color(98, 140, 88));
    }

    private void updateTimer() {
        timeRemaining--;  
        timerLabel.setText("Time Remaining: " + timeRemaining + "s");

        
        if (timeRemaining <= 0) {
            timer.stop();  
            String winner = player1Turn ? player2.getName() : player1.getName();
            JOptionPane.showMessageDialog(this, winner + " wins by timeout!");
            resetGame();  
        }
    }
}
